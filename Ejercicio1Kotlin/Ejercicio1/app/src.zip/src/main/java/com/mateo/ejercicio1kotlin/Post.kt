package com.mateo.ejercicio1kotlin

class Post {

    var username : String
    var status : String

    constructor(username : String, status: String) {
        this.username = username
        this.status = status
    }

}